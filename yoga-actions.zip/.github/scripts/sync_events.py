#!/usr/bin/env python3
"""
Синхронизация мероприятий Yoga Space.
Читает карточки с yogaspace.ru через Playwright (реальный браузер),
сравнивает с клоном и обновляет events.html, events-spb.html, index.html.
"""

import re
import json
import time
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup

MAIN_URL = "https://yogaspace.ru"

# ─── Шаблон карточки (Tilda t923) ────────────────────────────────────────────

def make_card(rec_id, slide_idx, card_num, lid, href, title, descr_html, img):
    if img and img.startswith('img/'):
        img_thumb = f"img/20x_{img.split('/')[-1]}"
    else:
        img_thumb = img or ""
    img = img or "img/tild3065-3630-4932-b134-313530396237_noroot.png"

    return (
        f'<div class="t-slds__item" data-slide-index="{slide_idx}"\n'
        f'role="group"\naria-roledescription="slide"\naria-label="{slide_idx} из 29">'
        f' <div class="t923__width_12 t-margin_auto t-width">'
        f' <div class="t923__slds-wrapper t-slds__wrapper t-align_center">'
        f' <div class="t-card__col t-card__col_withoutbtn t923__col t-col t-align_left" style="width: 360px">'
        f' <div class="t923__wrapper" data-blocks-per-row="3">'
        f' <div class="t923__imgwrapper t923__imgwrapper_4-3" style="background-color: #fff;"'
        f' bgimgfield="li_img__{lid}" itemscope itemtype="http://schema.org/ImageObject">'
        f' <meta itemprop="image" content="{img}">'
        f' <div class="t923__bgimg t-bgimg" data-original="{img}"'
        f' style="background-image:url(\'{img_thumb}\');"> </div>'
        f' </div>'
        f' <div class="t923__content" style="background-color: #fff;">'
        f' <div class="t923__textwrapper t923__paddingsmall">'
        f' <style> #{rec_id} .t-card__title{{font-size:18px;color:#242424;'
        f"font-family:'UnboundedNoto300';font-weight:500;}}"
        f'#{rec_id} .t-card__descr{{font-size:14px;color:#242424;'
        f"font-family:'Montserrat';font-weight:500;}}</style>"
        f' <div class="t-card__title t-name t-name_md" field="li_title__{lid}">'
        f' <a\nhref="{href}" target="_blank"\nclass="t-card__link"\n'
        f'id="cardtitle{card_num}_{rec_id[3:]}"\n'
        f'aria-labelledby="cardtitle{card_num}_{rec_id[3:]} cardbtn{card_num}_{rec_id[3:]}">'
        f' <span style="font-family: UnboundedNoto300; font-weight: 500;'
        f' color: rgb(92, 105, 55);">{title}</span>'
        f' </a> </div>'
        f' <div class="t-card__descr t-descr t-descr_xxs" field="li_descr__{lid}">'
        f' {descr_html} </div>'
        f' </div>'
        f' <div class="t-card__btn-wrapper t923__paddingsmall">'
        f' <div class="t-btn t-btnflex t-btnflex_type_button t-btnflex_sm t-card__btn"'
        f' type="button" id="cardbtn{card_num}_{rec_id[3:]}" data-lid="{lid}">'
        f'<span class="t-btnflex__text">Узнать больше</span>'
        f' <style>#{rec_id} .t-btnflex.t-btnflex_type_button'
        f' {{color:#fdf6f0;background-color:#5c6937;--border-width:0px;'
        f'border-style:none !important;border-radius:40px;box-shadow:none !important;'
        f'font-family:Montserrat;font-weight:500;transition-duration:0.2s;}}'
        f'@media (hover:hover) {{#{rec_id} .t-btnflex.t-btnflex_type_button'
        f':not(.t-animate_no-hover):hover {{background-color:#465128 !important;}}'
        f'#{rec_id} .t-btnflex.t-btnflex_type_button'
        f':not(.t-animate_no-hover):focus-visible'
        f' {{background-color:#465128 !important;}}}}</style>'
        f'</div> </div> </div> </div> </div> </div> </div> </div> '
    )


# ─── Парсинг карточек с основного сайта ──────────────────────────────────────

def scrape_events(page, url):
    """Открывает страницу в браузере и извлекает карточки мероприятий."""
    print(f"  Открываю {url}...")
    page.goto(url, wait_until="networkidle", timeout=60000)
    time.sleep(3)  # Ждём JS-рендер

    cards = []
    card_els = page.query_selector_all('.t-card')
    print(f"  Найдено карточек: {len(card_els)}")

    for el in card_els:
        try:
            link = el.query_selector('.t-card__link')
            title_el = el.query_selector('.t-card__title, .t-name')
            descr_el = el.query_selector('.t-card__descr')
            img_el = el.query_selector('.t-bgimg[data-original]')

            if not link or not title_el:
                continue

            href = link.get_attribute('href') or ''
            title = title_el.inner_text().strip()
            descr_html = descr_el.inner_html() if descr_el else ''
            img = img_el.get_attribute('data-original') if img_el else ''

            # Пропускаем пустые или навигационные элементы
            if not title or len(title) < 5:
                continue

            cards.append({
                'href': href,
                'title': title,
                'descr_html': descr_html,
                'img': img,
            })
            print(f"    ✓ {title[:60]}")

        except Exception as e:
            print(f"    ✗ Ошибка карточки: {e}")
            continue

    return cards


# ─── Замена блока карточек в HTML-файле ──────────────────────────────────────

def replace_cards_block(html_content, rec_id, new_cards_html):
    """Заменяет все слайды в блоке rec_id на новые."""
    start = html_content.find(f'id="{rec_id}"')
    if start == -1:
        print(f"  ⚠️  Блок {rec_id} не найден")
        return html_content

    end = html_content.find('<div id="rec', start + 100)
    block = html_content[start:end]

    # Находим заголовок блока (до первого слайда)
    first_slide = block.find('<div class="t-slds__item"')
    header = block[:first_slide]

    # Находим хвост (скрипты после последнего слайда)
    tail_start = block.find('<script>t_onReady', block.rfind('<div class="t-slds__item"'))
    tail = block[tail_start:]

    new_block = header + new_cards_html + tail
    return html_content[:start] + new_block + html_content[end:]


# ─── Основная логика ─────────────────────────────────────────────────────────

def main():
    print("🚀 Запуск синхронизации Yoga Space...")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        )
        page = context.new_page()

        # ── Москва ──
        print("\n📍 Москва — events.html")
        moscow_cards = scrape_events(page, f"{MAIN_URL}/events")

        if moscow_cards:
            print(f"  Генерирую {len(moscow_cards)} карточек...")
            cards_html = ""
            for i, card in enumerate(moscow_cards, 1):
                cards_html += make_card(
                    rec_id="rec2077460871",
                    slide_idx=i,
                    card_num=i,
                    lid=f"auto{i:04d}",
                    href=card['href'],
                    title=card['title'],
                    descr_html=card['descr_html'],
                    img=card['img'],
                )

            with open("events.html", "r", encoding="utf-8") as f:
                content = f.read()

            content = replace_cards_block(content, "rec2077460871", cards_html)

            with open("events.html", "w", encoding="utf-8") as f:
                f.write(content)
            print("  ✅ events.html обновлён")
        else:
            print("  ⚠️  Карточки не найдены, пропускаю")

        # ── Санкт-Петербург ──
        print("\n📍 Санкт-Петербург — events-spb.html")
        spb_cards = scrape_events(page, f"{MAIN_URL}/events-spb")

        if spb_cards:
            print(f"  Генерирую {len(spb_cards)} карточек...")
            cards_html = ""
            for i, card in enumerate(spb_cards, 1):
                cards_html += make_card(
                    rec_id="rec1619894371",
                    slide_idx=i,
                    card_num=i,
                    lid=f"spb{i:04d}",
                    href=card['href'],
                    title=card['title'],
                    descr_html=card['descr_html'],
                    img=card['img'],
                )

            with open("events-spb.html", "r", encoding="utf-8") as f:
                content = f.read()

            content = replace_cards_block(content, "rec1619894371", cards_html)

            with open("events-spb.html", "w", encoding="utf-8") as f:
                f.write(content)
            print("  ✅ events-spb.html обновлён")
        else:
            print("  ⚠️  Карточки не найдены, пропускаю")

        # ── Главная страница ──
        print("\n📍 Главная — index.html")
        with open("index.html", "r", encoding="utf-8") as f:
            index_content = f.read()

        # Берём первые 4 карточки Москвы для главной
        if moscow_cards:
            idx_html = ""
            for i, card in enumerate(moscow_cards[:4], 1):
                idx_html += make_card(
                    rec_id="rec2057026281",
                    slide_idx=i,
                    card_num=i,
                    lid=f"idx{i:04d}",
                    href=card['href'],
                    title=card['title'],
                    descr_html=card['descr_html'],
                    img=card['img'],
                )
            index_content = replace_cards_block(index_content, "rec2057026281", idx_html)

        # Берём первые 3 карточки СПБ для главной
        if spb_cards:
            spb_idx_html = ""
            for i, card in enumerate(spb_cards[:3], 1):
                spb_idx_html += make_card(
                    rec_id="rec2052257711",
                    slide_idx=i,
                    card_num=i,
                    lid=f"sidx{i:04d}",
                    href=card['href'],
                    title=card['title'],
                    descr_html=card['descr_html'],
                    img=card['img'],
                )
            index_content = replace_cards_block(index_content, "rec2052257711", spb_idx_html)

        with open("index.html", "w", encoding="utf-8") as f:
            f.write(index_content)
        print("  ✅ index.html обновлён")

        browser.close()

    print("\n🎉 Синхронизация завершена!")


if __name__ == "__main__":
    main()
